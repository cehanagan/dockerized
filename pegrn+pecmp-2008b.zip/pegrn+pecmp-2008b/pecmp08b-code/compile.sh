#!/bin/bash
gfortran -o pecmp08 *.f -O3