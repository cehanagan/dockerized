#!/bin/bash
gfortran -o pegrn08 *.f -O3