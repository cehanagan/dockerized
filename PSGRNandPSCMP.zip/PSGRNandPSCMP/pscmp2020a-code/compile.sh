#!/bin/bash
gfortran -o pscmp *.f -O3