#!/bin/bash

# Remove docker and image if it was previously built
docker stop chanagan/pscode
docker rm chanagan/pscode
docker image rm chanagan/pscode

# Build the docker image
# I believe --load makes the image local, push would put it on dockerhub?
docker buildx build --push --platform linux/arm64/v8,linux/amd64 --rm -t chanagan/pscode .

# Run the docker image as a container
# notebooks folder is an external volume - the notebook changes and 
# DataFiles produced from the notebooks are saved to your computer
# docker run spotl