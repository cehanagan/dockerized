#!/bin/bash
gfortran -o psgrn *.f -O3